import { users, movies, type User, type InsertUser, type Movie, type InsertMovie } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getMovie(id: number): Promise<Movie | undefined>;
  getMovies(): Promise<Movie[]>;
  getMoviesByCategory(category: string): Promise<Movie[]>;
  getFeaturedMovies(): Promise<Movie[]>;
  searchMovies(query: string): Promise<Movie[]>;
  createMovie(movie: InsertMovie): Promise<Movie>;
  updateMovie(id: number, movie: Partial<InsertMovie>): Promise<Movie | undefined>;
  deleteMovie(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private movies: Map<number, Movie>;
  private currentUserId: number;
  private currentMovieId: number;

  constructor() {
    this.users = new Map();
    this.movies = new Map();
    this.currentUserId = 1;
    this.currentMovieId = 1;
    
    // Initialize with some sample movies
    this.initializeSampleMovies();
  }

  private initializeSampleMovies() {
    const sampleMovies: InsertMovie[] = [
      {
        title: "The Dark Knight",
        description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.",
        quality: "HD 1080p",
        language: "English, Hindi",
        genre: "Action, Crime, Drama",
        trailerUrl: "https://www.youtube.com/watch?v=EXeTwQWrcwY",
        downloadUrl: "https://drive.google.com/file/d/example1",
        category: "hollywood",
        rating: "9.0",
        year: "2008",
        featured: true,
        thumbnail: "https://images.unsplash.com/photo-1489599904947-8e3f12e0faf8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Animal",
        description: "A son's love for his father leads him down a violent path of revenge and redemption in this intense crime drama.",
        quality: "4K UHD",
        language: "Hindi, English",
        genre: "Action, Crime, Drama",
        trailerUrl: "https://www.youtube.com/watch?v=1iqE1D_6Mw8",
        downloadUrl: "https://drive.google.com/file/d/animal-example",
        category: "bollywood",
        rating: "7.1",
        year: "2023",
        featured: true,
        thumbnail: "https://images.unsplash.com/photo-1516543212088-7cbdfb65a024?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Avengers: Endgame",
        description: "After the devastating events of Avengers: Infinity War, the universe is in ruins. With the help of remaining allies, the Avengers assemble once more.",
        quality: "4K UHD",
        language: "English, Hindi",
        genre: "Action, Adventure, Drama",
        trailerUrl: "https://www.youtube.com/watch?v=TcMBFSGVi1c",
        downloadUrl: "https://drive.google.com/file/d/example2",
        category: "hollywood",
        rating: "8.4",
        year: "2019",
        featured: true,
        thumbnail: "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Pathaan",
        description: "An exiled RAW agent partners with a Pakistani agent to take down a common enemy in this high-octane action thriller.",
        quality: "HD 1080p",
        language: "Hindi, English",
        genre: "Action, Thriller",
        trailerUrl: "https://www.youtube.com/watch?v=vqu4z34wENw",
        downloadUrl: "https://drive.google.com/file/d/example3",
        category: "bollywood",
        rating: "7.8",
        year: "2023",
        thumbnail: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "RRR",
        description: "A tale of two legendary revolutionaries and their journey far away from home. After their journey they return home to start fighting back against British colonialists.",
        quality: "4K UHD",
        language: "Telugu, Hindi, English",
        genre: "Action, Drama, History",
        trailerUrl: "https://www.youtube.com/watch?v=f_vbAtFSEc0",
        downloadUrl: "https://drive.google.com/file/d/example4",
        category: "south",
        rating: "8.8",
        year: "2022",
        featured: true,
        thumbnail: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "The Family Man 3",
        description: "A middle-class man secretly works for India's National Intelligence Agency whilst trying to preserve his family life.",
        quality: "HD 1080p",
        language: "Hindi, English",
        genre: "Action, Drama, Thriller",
        trailerUrl: "https://www.youtube.com/watch?v=RVKIVQGhxcY",
        downloadUrl: "https://drive.google.com/file/d/example5",
        category: "webseries",
        rating: "8.9",
        year: "2023",
        thumbnail: "https://images.unsplash.com/photo-1574267432553-4b4628081c31?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Jawan",
        description: "A man is driven by a personal vendetta to rectify the wrongs in society, while keeping a promise made years ago.",
        quality: "HD 1080p",
        language: "Hindi, Tamil, Telugu",
        genre: "Action, Crime, Thriller",
        trailerUrl: "https://www.youtube.com/watch?v=CEEtdmfvr8c",
        downloadUrl: "https://drive.google.com/file/d/jawan-example",
        category: "bollywood",
        rating: "7.2",
        year: "2023",
        thumbnail: "https://images.unsplash.com/photo-1585647347483-22b66260dfff?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Spider-Man: No Way Home",
        description: "With Spider-Man's identity now revealed, Peter asks Doctor Strange for help. When a spell goes wrong, dangerous foes from other worlds start to appear.",
        quality: "4K UHD",
        language: "English, Hindi",
        genre: "Action, Adventure, Sci-Fi",
        trailerUrl: "https://www.youtube.com/watch?v=JfVOs4VSpmA",
        downloadUrl: "https://drive.google.com/file/d/spiderman-example",
        category: "hollywood",
        rating: "8.4",
        year: "2021",
        thumbnail: "https://images.unsplash.com/photo-1635863138275-d9864d06ad8e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Pushpa: The Rise",
        description: "A laborer named Pushpa makes enemies as he rises in the world of red sandalwood smuggling. However, violence erupts when the police attempt to bring down his illegal business.",
        quality: "HD 1080p",
        language: "Telugu, Hindi, Tamil",
        genre: "Action, Crime, Drama",
        trailerUrl: "https://www.youtube.com/watch?v=pKctjlxbFDQ",
        downloadUrl: "https://drive.google.com/file/d/pushpa-example",
        category: "south",
        rating: "7.6",
        year: "2021",
        thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Wednesday",
        description: "Wednesday Addams investigates a murder spree while navigating her years as a student at Nevermore Academy.",
        quality: "HD 1080p",
        language: "English, Hindi",
        genre: "Comedy, Crime, Horror",
        trailerUrl: "https://www.youtube.com/watch?v=Di310WS8zLk",
        downloadUrl: "https://drive.google.com/file/d/wednesday-example",
        category: "webseries",
        rating: "8.1",
        year: "2022",
        thumbnail: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Scream VI",
        description: "The survivors of the Ghostface killings leave Woodsboro behind and start a fresh chapter in New York City.",
        quality: "4K UHD",
        language: "English, Hindi",
        genre: "Horror, Mystery, Thriller",
        trailerUrl: "https://www.youtube.com/watch?v=h74AXqw4Opc",
        downloadUrl: "https://drive.google.com/file/d/scream-example",
        category: "hollywood",
        rating: "6.5",
        year: "2023",
        thumbnail: "https://images.unsplash.com/photo-1489599904947-8e3f12e0faf8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      },
      {
        title: "Kantara",
        description: "It involves culture of Kambla and Bhootha Kola. A human and nature conflict where Shiva is the rebel who defends his village and nature.",
        quality: "HD 1080p",
        language: "Kannada, Hindi, Telugu",
        genre: "Action, Drama, Thriller",
        trailerUrl: "https://www.youtube.com/watch?v=8mrVmf239GU",
        downloadUrl: "https://drive.google.com/file/d/kantara-example",
        category: "south",
        rating: "8.2",
        year: "2022",
        thumbnail: "https://images.unsplash.com/photo-1611173596719-1c0b5cde5bb1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"
      }
    ];

    sampleMovies.forEach(movie => {
      this.createMovie(movie);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getMovie(id: number): Promise<Movie | undefined> {
    return this.movies.get(id);
  }

  async getMovies(): Promise<Movie[]> {
    return Array.from(this.movies.values());
  }

  async getMoviesByCategory(category: string): Promise<Movie[]> {
    return Array.from(this.movies.values()).filter(
      movie => movie.category === category
    );
  }

  async getFeaturedMovies(): Promise<Movie[]> {
    return Array.from(this.movies.values()).filter(
      movie => movie.featured === true
    );
  }

  async searchMovies(query: string): Promise<Movie[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.movies.values()).filter(
      movie => 
        movie.title.toLowerCase().includes(searchTerm) ||
        movie.description.toLowerCase().includes(searchTerm) ||
        movie.genre.toLowerCase().includes(searchTerm)
    );
  }

  async createMovie(insertMovie: InsertMovie): Promise<Movie> {
    const id = this.currentMovieId++;
    const movie: Movie = { ...insertMovie, id };
    this.movies.set(id, movie);
    return movie;
  }

  async updateMovie(id: number, updateData: Partial<InsertMovie>): Promise<Movie | undefined> {
    const movie = this.movies.get(id);
    if (!movie) return undefined;
    
    const updatedMovie = { ...movie, ...updateData };
    this.movies.set(id, updatedMovie);
    return updatedMovie;
  }

  async deleteMovie(id: number): Promise<boolean> {
    return this.movies.delete(id);
  }
}

export const storage = new MemStorage();
