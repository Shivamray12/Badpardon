import { Film } from "lucide-react";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
  className?: string;
}

export default function Logo({ size = "md", showText = true, className = "" }: LogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10", 
    lg: "w-16 h-16"
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-4xl md:text-6xl"
  };

  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      {/* Use the skull logo from assets or fallback to icon */}
      <div className="relative">

        <div className={`${sizeClasses[size]} bg-brand-red rounded-lg hidden items-center justify-center`}>
          <Film className="text-white h-6 w-6" />
        </div>
      </div>
      
      {showText && (
        <div>
          <span className={`${textSizeClasses[size]} font-bold text-white`}>
            Badparadon Movie
          </span>
          {size === "lg" && (
            <p className="text-gray-300 text-lg">Your Ultimate Movie Download Destination</p>
          )}
        </div>
      )}
    </div>
  );
}