import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { insertMovieSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import type { InsertMovie } from "@shared/schema";

interface AdminUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminUploadModal({ isOpen, onClose }: AdminUploadModalProps) {
  const [isVerified, setIsVerified] = useState(false);
  const [password, setPassword] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertMovie>({
    resolver: zodResolver(insertMovieSchema),
    defaultValues: {
      title: "",
      description: "",
      quality: "",
      language: "",
      genre: "",
      trailerUrl: "",
      downloadUrl: "",
      category: "",
      year: new Date().getFullYear().toString(),
      rating: "0.0",
      featured: false,
    },
  });

  const verifyMutation = useMutation({
    mutationFn: async (password: string) => {
      const response = await apiRequest("POST", "/api/admin/verify", { password });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        setIsVerified(true);
        toast({
          title: "Success",
          description: "Admin access verified!",
        });
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Incorrect password! Access denied.",
        variant: "destructive",
      });
      setPassword("");
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: InsertMovie & { password: string }) => {
      const response = await apiRequest("POST", "/api/admin/movies", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Movie uploaded successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to upload movie",
        variant: "destructive",
      });
    },
  });

  const handleVerify = () => {
    if (password.trim()) {
      verifyMutation.mutate(password);
    }
  };

  const handleClose = () => {
    setIsVerified(false);
    setPassword("");
    form.reset();
    onClose();
  };

  const onSubmit = (data: InsertMovie) => {
    uploadMutation.mutate({ ...data, password });
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-dark-secondary border-dark-tertiary max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Admin - Upload Movie</DialogTitle>
        </DialogHeader>

        {!isVerified ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Admin Password</label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                className="bg-dark-primary border-dark-tertiary focus:border-brand-red"
                onKeyPress={(e) => e.key === 'Enter' && handleVerify()}
              />
            </div>
            <Button
              onClick={handleVerify}
              disabled={verifyMutation.isPending || !password.trim()}
              className="bg-brand-red hover:bg-red-700"
            >
              {verifyMutation.isPending ? "Verifying..." : "Verify Access"}
            </Button>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Movie Title</FormLabel>
                    <FormControl>
                      <Input {...field} className="bg-dark-primary border-dark-tertiary focus:border-brand-red" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        rows={4}
                        className="bg-dark-primary border-dark-tertiary focus:border-brand-red"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="quality"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quality</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-dark-primary border-dark-tertiary focus:border-brand-red">
                            <SelectValue placeholder="Select Quality" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-dark-primary border-dark-tertiary">
                          <SelectItem value="HD 720p">HD 720p</SelectItem>
                          <SelectItem value="HD 1080p">HD 1080p</SelectItem>
                          <SelectItem value="4K UHD">4K UHD</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="language"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Language</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          placeholder="e.g., English, Hindi"
                          className="bg-dark-primary border-dark-tertiary focus:border-brand-red"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="genre"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Genre</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          placeholder="e.g., Action, Drama, Comedy"
                          className="bg-dark-primary border-dark-tertiary focus:border-brand-red"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="year"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Year</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          placeholder="2023"
                          className="bg-dark-primary border-dark-tertiary focus:border-brand-red"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="trailerUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>YouTube Trailer Link</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="url"
                        placeholder="https://youtube.com/watch?v=..."
                        className="bg-dark-primary border-dark-tertiary focus:border-brand-red"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="downloadUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Google Drive Download Link</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="url"
                        placeholder="https://drive.google.com/..."
                        className="bg-dark-primary border-dark-tertiary focus:border-brand-red"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-dark-primary border-dark-tertiary focus:border-brand-red">
                          <SelectValue placeholder="Select Category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-dark-primary border-dark-tertiary">
                        <SelectItem value="bollywood">Bollywood</SelectItem>
                        <SelectItem value="south">South Indian</SelectItem>
                        <SelectItem value="hollywood">Hollywood</SelectItem>
                        <SelectItem value="webseries">Web Series</SelectItem>
                        <SelectItem value="adult">18+</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                disabled={uploadMutation.isPending}
                className="w-full bg-brand-red hover:bg-red-700 py-3 text-lg font-semibold"
              >
                {uploadMutation.isPending ? "Uploading..." : "Upload Movie"}
              </Button>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
