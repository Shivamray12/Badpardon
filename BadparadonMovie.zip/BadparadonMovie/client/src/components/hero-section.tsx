import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Download, Star } from "lucide-react";
import type { Movie } from "@shared/schema";

interface HeroSectionProps {
  featuredMovie?: Movie;
}

export default function HeroSection({ featuredMovie }: HeroSectionProps) {
  if (!featuredMovie) {
    return (
      <section className="relative h-screen overflow-hidden bg-dark-secondary">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-4">Welcome to Badparadon Movie</h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8">
              Your ultimate destination for the latest movies and web series
            </p>
          </div>
        </div>
      </section>
    );
  }

  const handleDownload = () => {
    window.open(featuredMovie.downloadUrl, '_blank');
  };

  const handleWatchTrailer = () => {
    window.location.href = `/movie/${featuredMovie.id}`;
  };

  return (
    <section className="relative h-screen overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${featuredMovie.thumbnail || "https://images.unsplash.com/photo-1489599904947-8e3f12e0faf8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"})`
        }}
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-dark-primary via-dark-primary/80 to-transparent" />
      
      <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
        <div className="max-w-2xl">
          <h1 className="text-5xl md:text-7xl font-bold mb-4">
            {featuredMovie.title}
          </h1>
          
          <p className="text-lg md:text-xl text-gray-300 mb-6 leading-relaxed">
            {featuredMovie.description}
          </p>
          
          {/* Movie Info Badges */}
          <div className="flex flex-wrap gap-2 mb-8">
            {featuredMovie.genre.split(', ').map((genre, index) => (
              <Badge 
                key={index}
                variant={index === 0 ? "default" : "secondary"}
                className={index === 0 ? "bg-brand-red" : ""}
              >
                {genre}
              </Badge>
            ))}
            <Badge variant="outline" className="border-yellow-500 text-yellow-500">
              <Star className="mr-1 h-3 w-3 fill-yellow-500" />
              IMDb {featuredMovie.rating}
            </Badge>
          </div>
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              onClick={handleDownload}
              className="bg-brand-red hover:bg-red-700 px-8 py-3 text-lg font-semibold"
              size="lg"
            >
              <Download className="mr-2 h-5 w-5" />
              Download HD
            </Button>
            <Button 
              onClick={handleWatchTrailer}
              variant="outline"
              className="border-gray-600 hover:bg-gray-800 px-8 py-3 text-lg font-semibold"
              size="lg"
            >
              <Play className="mr-2 h-5 w-5" />
              Watch Trailer
            </Button>
          </div>
          
          {/* Movie Details */}
          <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-400 block">Year</span>
              <span className="font-semibold">{featuredMovie.year}</span>
            </div>
            <div>
              <span className="text-gray-400 block">Quality</span>
              <span className="font-semibold">{featuredMovie.quality}</span>
            </div>
            <div>
              <span className="text-gray-400 block">Language</span>
              <span className="font-semibold">{featuredMovie.language}</span>
            </div>
            <div>
              <span className="text-gray-400 block">Category</span>
              <span className="font-semibold capitalize">{featuredMovie.category}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
