import { Star, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Movie } from "@shared/schema";

interface MovieCardProps {
  movie: Movie;
  onClick?: () => void;
}

export default function MovieCard({ movie, onClick }: MovieCardProps) {
  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    window.open(movie.downloadUrl, '_blank');
  };

  return (
    <div 
      className="bg-dark-secondary rounded-lg overflow-hidden cursor-pointer hover:scale-105 transition-transform duration-300 shadow-lg"
      onClick={onClick}
    >
      <div className="relative">
        <img
          src={movie.thumbnail || "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"}
          alt={movie.title}
          className="w-full h-64 object-cover"
        />
        <div className="absolute top-2 right-2">
          <span className="bg-green-600 px-2 py-1 rounded text-xs font-semibold text-white">
            {movie.quality}
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2 truncate" title={movie.title}>
          {movie.title}
        </h3>
        
        <div className="flex justify-between items-center text-sm text-gray-400 mb-3">
          <span>{movie.year}</span>
          <span className="capitalize">{movie.category}</span>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
            <span className="text-sm font-medium">{movie.rating}</span>
          </div>
          <Button
            size="sm"
            variant="ghost"
            className="text-brand-red hover:text-red-400 hover:bg-red-500/10"
            onClick={handleDownload}
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
