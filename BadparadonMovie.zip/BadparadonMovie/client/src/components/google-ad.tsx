import { useEffect } from "react";

interface GoogleAdProps {
  adSlot: string;
  adFormat?: "auto" | "rectangle" | "vertical" | "horizontal";
  adStyle?: React.CSSProperties;
  className?: string;
  adClient?: string;
}

export default function GoogleAd({ 
  adSlot, 
  adFormat = "auto", 
  adStyle = {},
  className = "",
  adClient = "ca-pub-XXXXXXXXXXXXXXXXX" // Replace with your actual AdSense client ID
}: GoogleAdProps) {
  
  useEffect(() => {
    try {
      // Check if AdSense script is loaded
      if (typeof window !== 'undefined' && (window as any).adsbygoogle) {
        ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
      }
    } catch (error) {
      console.log('AdSense not loaded yet');
    }
  }, []);

  return (
    <div className={`ad-container ${className}`}>
      <ins
        className="adsbygoogle"
        style={{
          display: "block",
          width: "100%",
          height: "auto",
          ...adStyle
        }}
        data-ad-client={adClient}
        data-ad-slot={adSlot}
        data-ad-format={adFormat}
        data-full-width-responsive="true"
      />
    </div>
  );
}

// Predefined ad components for different placements
export function HeaderAd() {
  return (
    <GoogleAd
      adSlot="1234567890" // Replace with your header ad slot
      adFormat="horizontal"
      className="my-4"
      adStyle={{ minHeight: "90px" }}
    />
  );
}

export function SidebarAd() {
  return (
    <GoogleAd
      adSlot="2345678901" // Replace with your sidebar ad slot
      adFormat="vertical"
      className="my-4"
      adStyle={{ minHeight: "250px", width: "300px" }}
    />
  );
}

export function BannerAd() {
  return (
    <GoogleAd
      adSlot="3456789012" // Replace with your banner ad slot
      adFormat="rectangle"
      className="my-6"
      adStyle={{ minHeight: "100px" }}
    />
  );
}

export function FooterAd() {
  return (
    <GoogleAd
      adSlot="4567890123" // Replace with your footer ad slot
      adFormat="horizontal"
      className="my-4"
      adStyle={{ minHeight: "90px" }}
    />
  );
}