import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Film, Search, Menu, X, User } from "lucide-react";
import Logo from "@/components/logo";

interface NavigationProps {
  onSearch?: (query: string) => void;
}

export default function Navigation({ onSearch }: NavigationProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchQuery);
    }
  };

  const clearSearch = () => {
    setSearchQuery("");
    if (onSearch) {
      onSearch("");
    }
  };

  return (
    <header className="fixed top-0 w-full bg-dark-primary/95 backdrop-blur-sm z-50 border-b border-dark-tertiary">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" onClick={clearSearch}>
            <Logo size="md" showText={true} className="group-hover:text-brand-red transition-colors duration-300" />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            <Link href="/" onClick={clearSearch}>
              <span className="text-white hover:text-brand-red transition-colors cursor-pointer">Home</span>
            </Link>
            <a href="#bollywood" className="text-gray-300 hover:text-brand-red transition-colors">
              Bollywood
            </a>
            <a href="#south" className="text-gray-300 hover:text-brand-red transition-colors">
              South
            </a>
            <a href="#hollywood" className="text-gray-300 hover:text-brand-red transition-colors">
              Hollywood
            </a>
            <a href="#webseries" className="text-gray-300 hover:text-brand-red transition-colors">
              Web Series
            </a>
          </div>

          {/* Search and Profile */}
          <div className="flex items-center space-x-4">
            {/* Desktop Search */}
            <form onSubmit={handleSearch} className="relative hidden md:block">
              <Input
                type="text"
                placeholder="Search movies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-dark-secondary border-dark-tertiary rounded-lg px-4 py-2 pr-10 focus:border-brand-red w-64"
              />
              <Button
                type="submit"
                size="sm"
                variant="ghost"
                className="absolute right-1 top-1/2 transform -translate-y-1/2 p-2"
              >
                <Search className="h-4 w-4 text-gray-400" />
              </Button>
            </form>

            {/* Mobile Search Toggle */}
            <Button 
              variant="ghost" 
              size="sm" 
              className="md:hidden text-white"
            >
              <Search className="h-5 w-5" />
            </Button>

            {/* Profile */}
            <Button variant="ghost" size="sm" className="text-white">
              <User className="h-5 w-5" />
            </Button>

            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Search */}
        <form onSubmit={handleSearch} className="mt-4 md:hidden">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search movies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-dark-secondary border-dark-tertiary rounded-lg px-4 py-2 pr-10 focus:border-brand-red w-full"
            />
            <Button
              type="submit"
              size="sm"
              variant="ghost"
              className="absolute right-1 top-1/2 transform -translate-y-1/2 p-2"
            >
              <Search className="h-4 w-4 text-gray-400" />
            </Button>
          </div>
        </form>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden mt-4 py-4 border-t border-dark-tertiary">
            <div className="flex flex-col space-y-4">
              <Link href="/" onClick={() => { clearSearch(); setIsMenuOpen(false); }}>
                <a className="text-white hover:text-brand-red transition-colors">Home</a>
              </Link>
              <a href="#bollywood" className="text-gray-300 hover:text-brand-red transition-colors">
                Bollywood
              </a>
              <a href="#south" className="text-gray-300 hover:text-brand-red transition-colors">
                South
              </a>
              <a href="#hollywood" className="text-gray-300 hover:text-brand-red transition-colors">
                Hollywood
              </a>
              <a href="#webseries" className="text-gray-300 hover:text-brand-red transition-colors">
                Web Series
              </a>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
