import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import MovieGrid from "@/components/movie-grid";
import AdminUploadModal from "@/components/admin-upload-modal";
import { Button } from "@/components/ui/button";
import { Plus, Star, Film, Tv, Globe } from "lucide-react";
import type { Movie } from "@shared/schema";

export default function Home() {
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: movies = [], isLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  const { data: featuredMovies = [] } = useQuery<Movie[]>({
    queryKey: ["/api/featured"],
  });

  const { data: searchResults = [] } = useQuery<Movie[]>({
    queryKey: ["/api/search", searchQuery],
    enabled: searchQuery.length > 0,
  });

  const bollywoodMovies = movies.filter(movie => movie.category === "bollywood");
  const southMovies = movies.filter(movie => movie.category === "south");
  const hollywoodMovies = movies.filter(movie => movie.category === "hollywood");
  const webSeries = movies.filter(movie => movie.category === "webseries");
  const adultMovies = movies.filter(movie => movie.category === "adult");

  // Get trending movies (high-rated recent movies)
  const trendingMovies = movies
    .filter(movie => parseFloat(movie.rating || "0") >= 7.5)
    .sort((a, b) => parseInt(b.year) - parseInt(a.year))
    .slice(0, 4);

  // Recently uploaded (sorted by latest)
  const recentMovies = movies
    .sort((a, b) => parseInt(b.year) - parseInt(a.year))
    .slice(0, 8);

  // Top downloads (highest rated)
  const topDownloads = movies
    .sort((a, b) => parseFloat(b.rating || "0") - parseFloat(a.rating || "0"))
    .slice(0, 8);

  const displayedMovies = searchQuery ? searchResults : movies;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-primary flex items-center justify-center">
        <div className="text-center fade-in">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-brand-red"></div>
          <p className="mt-4 text-gray-400">Loading movies...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-primary">
      <Navigation onSearch={setSearchQuery} />
      
      {!searchQuery && (
        <>
          {/* Top Banner with Logo */}
          <section className="pt-20 pb-4 bg-gradient-to-r from-dark-primary via-dark-secondary to-dark-primary">
            <div className="container mx-auto px-4">
              <div className="flex items-center justify-center space-x-4 py-6">
                <img 
                  src="@assets/logo.webp"
                  alt="Badparadon Logo" 
                  className="w-16 h-16 object-contain animate-slide-in"
                />
                <div className="text-center fade-in-delay">
                  <h1 className="text-4xl md:text-6xl font-bold text-white mb-2">Badparadon Movie</h1>
                  <p className="text-gray-300 text-lg">Your Ultimate Movie Download Destination</p>
                </div>
              </div>
            </div>
          </section>

          {/* Trending Movies Section */}
          {trendingMovies.length > 0 && (
            <section className="py-12 bg-gradient-secondary fade-in">
              <div className="container mx-auto px-4">
                <h2 className="text-4xl font-bold mb-8 flex items-center">
                  <div className="text-brand-red mr-4 text-3xl">🔥</div>
                  Trending Now
                  <div className="ml-4 text-sm bg-brand-red text-white px-3 py-1 rounded-full">HOT</div>
                </h2>
                <div className="flex space-x-6 overflow-x-auto trending-scroll pb-4">
                  {trendingMovies.map((movie, index) => (
                    <div
                      key={movie.id}
                      className={`flex-shrink-0 w-80 bg-dark-primary rounded-xl overflow-hidden cursor-pointer trending-poster shadow-2xl ${index === 0 ? 'fade-in' : 'fade-in-delay'}`}
                      onClick={() => window.location.href = `/movie/${movie.id}`}
                    >
                      <div className="relative">
                        <img 
                          src={movie.thumbnail || "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"} 
                          alt={movie.title}
                          className="w-full h-96 object-cover"
                        />
                        <div className="absolute top-4 right-4">
                          <span className="bg-brand-red px-3 py-1 rounded-full text-sm font-bold text-white shadow-lg">
                            {movie.quality}
                          </span>
                        </div>
                        <div className="absolute bottom-4 left-4">
                          <div className="flex items-center space-x-2">
                            <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                            <span className="text-white font-bold bg-black/50 px-2 py-1 rounded">{movie.rating}</span>
                          </div>
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="font-bold text-xl mb-3 text-white">{movie.title}</h3>
                        <div className="flex justify-between items-center text-gray-400 mb-3">
                          <span className="text-lg">{movie.year}</span>
                          <span className="capitalize bg-gray-700 px-2 py-1 rounded text-sm">{movie.category}</span>
                        </div>
                        <p className="text-gray-300 text-sm line-clamp-2 mb-4">{movie.description}</p>
                        <Button className="w-full bg-brand-red hover:bg-red-700 btn-hover-glow">
                          Watch Now
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* Ad Banner */}
          <section className="py-8 bg-dark-primary fade-in-delay">
            <div className="container mx-auto px-4">
              <div className="bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 border-2 border-dashed border-gray-600 rounded-xl p-8 text-center shadow-lg">
                <div className="text-4xl text-gray-500 mb-4">📢</div>
                <p className="text-gray-300 text-lg font-semibold">Advertisement Space - 900x100 Banner</p>
                <p className="text-sm text-gray-500 mt-2">Google AdSense / Premium Banner Placement</p>
              </div>
            </div>
          </section>

          {/* Recently Uploaded Movies */}
          {recentMovies.length > 0 && (
            <section className="py-12 bg-gradient-primary fade-in">
              <div className="container mx-auto px-4">
                <h2 className="text-4xl font-bold mb-8 flex items-center">
                  <div className="text-green-500 mr-4 text-3xl">🆕</div>
                  Recently Uploaded Movies
                  <div className="ml-4 text-sm bg-green-600 text-white px-3 py-1 rounded-full">NEW</div>
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-6">
                  {recentMovies.map((movie, index) => (
                    <div
                      key={movie.id}
                      className={`movie-card bg-dark-secondary rounded-lg overflow-hidden cursor-pointer shadow-lg ${index < 4 ? 'fade-in' : 'fade-in-delay'}`}
                      onClick={() => window.location.href = `/movie/${movie.id}`}
                    >
                      <div className="relative">
                        <img
                          src={movie.thumbnail || "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"}
                          alt={movie.title}
                          className="w-full h-64 object-cover"
                        />
                        <div className="absolute top-2 right-2">
                          <span className="bg-green-600 px-2 py-1 rounded text-xs font-semibold text-white">
                            {movie.quality}
                          </span>
                        </div>
                        <div className="absolute top-2 left-2">
                          <span className="bg-brand-red px-2 py-1 rounded text-xs font-semibold text-white">
                            {movie.year}
                          </span>
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold text-lg mb-2 truncate text-white" title={movie.title}>
                          {movie.title}
                        </h3>
                        <div className="flex justify-between items-center text-sm text-gray-400 mb-3">
                          <span className="capitalize">{movie.category}</span>
                          <div className="flex items-center space-x-1">
                            <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                            <span className="text-sm font-medium">{movie.rating}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* Top Downloads */}
          {topDownloads.length > 0 && (
            <section className="py-12 bg-gradient-secondary fade-in-delay">
              <div className="container mx-auto px-4">
                <h2 className="text-4xl font-bold mb-8 flex items-center">
                  <div className="text-yellow-500 mr-4 text-3xl">👑</div>
                  Top Downloads
                  <div className="ml-4 text-sm bg-yellow-600 text-white px-3 py-1 rounded-full">POPULAR</div>
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-6">
                  {topDownloads.map((movie, index) => (
                    <div
                      key={movie.id}
                      className={`movie-card bg-dark-primary rounded-lg overflow-hidden cursor-pointer shadow-lg ${index < 4 ? 'fade-in' : 'fade-in-delay'}`}
                      onClick={() => window.location.href = `/movie/${movie.id}`}
                    >
                      <div className="relative">
                        <img
                          src={movie.thumbnail || "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"}
                          alt={movie.title}
                          className="w-full h-64 object-cover"
                        />
                        <div className="absolute top-2 right-2">
                          <span className="bg-yellow-600 px-2 py-1 rounded text-xs font-semibold text-white">
                            #{index + 1}
                          </span>
                        </div>
                        <div className="absolute bottom-2 left-2">
                          <div className="flex items-center space-x-1 bg-black/70 px-2 py-1 rounded">
                            <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                            <span className="text-white text-xs font-bold">{movie.rating}</span>
                          </div>
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold text-lg mb-2 truncate text-white" title={movie.title}>
                          {movie.title}
                        </h3>
                        <div className="flex justify-between items-center text-sm text-gray-400 mb-3">
                          <span>{movie.year}</span>
                          <span className="capitalize bg-gray-700 px-2 py-1 rounded text-xs">{movie.category}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* Bollywood Section */}
          {bollywoodMovies.length > 0 && (
            <section id="bollywood" className="py-12 bg-gradient-primary fade-in">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold mb-8 flex items-center">
                  <Star className="text-yellow-500 mr-3 h-8 w-8" />
                  Bollywood Movies
                </h2>
                <MovieGrid movies={bollywoodMovies.slice(0, 8)} />
                {bollywoodMovies.length > 8 && (
                  <div className="text-center mt-8">
                    <Button className="bg-brand-red hover:bg-red-700 btn-hover-glow">
                      View All Bollywood Movies
                    </Button>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* South Indian Movies Section */}
          {southMovies.length > 0 && (
            <section id="south" className="py-12 bg-dark-primary">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold mb-8 flex items-center">
                  <Film className="text-orange-500 mr-3 h-8 w-8" />
                  South Indian Movies
                </h2>
                <MovieGrid movies={southMovies.slice(0, 10)} />
              </div>
            </section>
          )}

          {/* Hollywood Section */}
          {hollywoodMovies.length > 0 && (
            <section id="hollywood" className="py-12 bg-dark-secondary">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold mb-8 flex items-center">
                  <Globe className="text-blue-500 mr-3 h-8 w-8" />
                  Hollywood Movies
                </h2>
                <MovieGrid movies={hollywoodMovies.slice(0, 10)} />
              </div>
            </section>
          )}

          {/* Web Series Section */}
          {webSeries.length > 0 && (
            <section id="webseries" className="py-12 bg-dark-primary">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold mb-8 flex items-center">
                  <Tv className="text-purple-500 mr-3 h-8 w-8" />
                  Web Series
                </h2>
                <MovieGrid movies={webSeries.slice(0, 10)} />
              </div>
            </section>
          )}
        </>
      )}

      {/* Search Results */}
      {searchQuery && (
        <section className="py-12 bg-dark-primary min-h-screen pt-24">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">
              Search Results for "{searchQuery}"
            </h2>
            {displayedMovies.length > 0 ? (
              <MovieGrid movies={displayedMovies} />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-400 text-xl">No movies found for "{searchQuery}"</p>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-gradient-to-r from-dark-primary via-dark-secondary to-dark-primary border-t border-brand-red/30 py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-4 mb-6">
                <img 
                  src="@assets/logo.webp"
                  alt="Badparadon Logo" 
                  className="w-12 h-12 object-contain"
                />
                <div>
                  <span className="text-2xl font-bold text-white">Badparadon Movie</span>
                  <p className="text-brand-red text-sm font-semibold">Premium Downloads</p>
                </div>
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Your ultimate destination for latest movies and web series downloads in HD quality. 
                Experience cinema like never before with our premium collection.
              </p>
              <div className="flex space-x-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-brand-red">{movies.length}+</div>
                  <div className="text-sm text-gray-400">Movies</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-brand-red">4K</div>
                  <div className="text-sm text-gray-400">Quality</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-brand-red">24/7</div>
                  <div className="text-sm text-gray-400">Available</div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-bold mb-6 text-white text-lg">Categories</h3>
              <ul className="space-y-3 text-gray-400">
                <li><a href="#bollywood" className="hover:text-brand-red transition-colors flex items-center">
                  <span className="w-2 h-2 bg-brand-red rounded-full mr-3"></span>Bollywood
                </a></li>
                <li><a href="#south" className="hover:text-brand-red transition-colors flex items-center">
                  <span className="w-2 h-2 bg-brand-red rounded-full mr-3"></span>South Indian
                </a></li>
                <li><a href="#hollywood" className="hover:text-brand-red transition-colors flex items-center">
                  <span className="w-2 h-2 bg-brand-red rounded-full mr-3"></span>Hollywood
                </a></li>
                <li><a href="#webseries" className="hover:text-brand-red transition-colors flex items-center">
                  <span className="w-2 h-2 bg-brand-red rounded-full mr-3"></span>Web Series
                </a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-6 text-white text-lg">Legal & Support</h3>
              <ul className="space-y-3 text-gray-400">
                <li><a href="#" className="hover:text-brand-red transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">DMCA</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-brand-red/20 mt-12 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="flex items-center space-x-4 mb-4 md:mb-0">
                <img 
                  src="@assets/logo.webp"
                  alt="Badparadon Logo" 
                  className="w-8 h-8 object-contain"
                />
                <p className="text-gray-400">
                  &copy; 2024 Badparadon Movie. All rights reserved.
                </p>
              </div>
              <div className="flex items-center space-x-6">
                <a href="/sitemap.xml" className="text-gray-400 hover:text-brand-red transition-colors text-sm">Sitemap</a>
                <span className="text-brand-red font-semibold text-sm">Made with ❤️ for Movie Lovers</span>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Admin Button */}
      <Button
        onClick={() => setShowAdminModal(true)}
        className="fixed bottom-6 right-6 bg-brand-red hover:bg-red-700 w-14 h-14 rounded-full shadow-lg z-40"
        size="icon"
      >
        <Plus className="h-6 w-6" />
      </Button>

      <AdminUploadModal 
        isOpen={showAdminModal}
        onClose={() => setShowAdminModal(false)}
      />
    </div>
  );
}
