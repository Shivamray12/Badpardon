import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Download, Share2, ArrowLeft } from "lucide-react";
import type { Movie } from "@shared/schema";

export default function MovieDetail() {
  const { id } = useParams();
  
  const { data: movie, isLoading } = useQuery<Movie>({
    queryKey: [`/api/movies/${id}`],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-primary flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-brand-red"></div>
          <p className="mt-4 text-gray-400">Loading movie details...</p>
        </div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="min-h-screen bg-dark-primary flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Movie Not Found</h1>
          <p className="text-gray-400 mb-8">The movie you're looking for doesn't exist.</p>
          <Button onClick={() => window.history.back()} variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  const getYouTubeEmbedUrl = (url: string) => {
    const regex = /(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/;
    const match = url.match(regex);
    if (match && match[1]) {
      return `https://www.youtube.com/embed/${match[1]}?autoplay=1`;
    }
    return url;
  };

  const handleDownload = () => {
    window.open(movie.downloadUrl, '_blank');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: movie.title,
        text: movie.description,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Movie link copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-dark-primary">
      <Navigation />
      
      <div className="pt-20">
        {/* YouTube Trailer */}
        <div className="aspect-video max-w-6xl mx-auto">
          <iframe
            width="100%"
            height="100%"
            src={getYouTubeEmbedUrl(movie.trailerUrl)}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="rounded-lg"
          />
        </div>

        {/* Movie Details */}
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-start gap-2 mb-6">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => window.history.back()}
                className="text-gray-400 hover:text-white"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Movie Poster */}
              <div className="lg:col-span-1">
                <img
                  src={movie.thumbnail || "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"}
                  alt={movie.title}
                  className="w-full rounded-lg shadow-2xl"
                />
              </div>

              {/* Movie Info */}
              <div className="lg:col-span-2">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">{movie.title}</h1>
                
                {/* Genre badges */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {movie.genre.split(', ').map((genre, index) => (
                    <Badge 
                      key={index}
                      variant={index === 0 ? "default" : "secondary"}
                      className={index === 0 ? "bg-brand-red" : ""}
                    >
                      {genre}
                    </Badge>
                  ))}
                </div>

                <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                  {movie.description}
                </p>

                {/* Movie Details Grid */}
                <div className="grid grid-cols-2 gap-6 mb-8">
                  <div>
                    <span className="text-gray-400 block text-sm mb-1">Quality</span>
                    <span className="font-semibold text-lg">{movie.quality}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block text-sm mb-1">Language</span>
                    <span className="font-semibold text-lg">{movie.language}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block text-sm mb-1">Release Year</span>
                    <span className="font-semibold text-lg">{movie.year}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block text-sm mb-1">IMDb Rating</span>
                    <div className="flex items-center">
                      <Star className="h-5 w-5 text-yellow-500 fill-yellow-500 mr-1" />
                      <span className="font-semibold text-lg">{movie.rating}</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    onClick={handleDownload}
                    className="bg-brand-red hover:bg-red-700 text-white px-8 py-3 text-lg font-semibold flex-1"
                    size="lg"
                  >
                    <Download className="mr-2 h-5 w-5" />
                    Download Now
                  </Button>
                  <Button 
                    onClick={handleShare}
                    variant="outline"
                    className="border-gray-600 hover:bg-gray-800 px-8 py-3 text-lg font-semibold"
                    size="lg"
                  >
                    <Share2 className="mr-2 h-5 w-5" />
                    Share
                  </Button>
                </div>

                {/* Ad Placeholder */}
                <div className="mt-8 bg-dark-secondary border-2 border-dashed border-gray-600 rounded-lg p-6 text-center">
                  <div className="text-2xl text-gray-500 mb-2">📱</div>
                  <p className="text-gray-400">Advertisement Space</p>
                  <p className="text-sm text-gray-500">Banner Placement</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
