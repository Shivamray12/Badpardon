from flask import Flask
from threading import Thread
import time
import requests

app = Flask('')

@app.route('/')
def home():
    return "Badparadon Movie Server is alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

def ping_server():
    """Ping the server every 5 minutes to keep it alive"""
    while True:
        try:
            # Ping the main Node.js server
            requests.get('http://localhost:5000')
            print("✓ Server pinged successfully")
        except:
            print("✗ Failed to ping server")
        time.sleep(300)  # Wait 5 minutes

if __name__ == '__main__':
    keep_alive()
    
    # Start the ping process
    ping_thread = Thread(target=ping_server)
    ping_thread.daemon = True
    ping_thread.start()
    
    print("🚀 Keep-alive server started on port 8080")
    print("🔄 Auto-ping enabled (every 5 minutes)")